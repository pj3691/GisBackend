import os

assert(os.path.isfile("tai-utc.dat"))
